export default async function handler(req, res) {
  if (req.method !== "POST") {
    res.setHeader("Allow", "POST");
    return res.status(405).json({ error: "Use POST for chat requests." });
  }

  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) {
    return res.status(500).json({ error: "The website owner has not added the OpenAI API key in Vercel yet." });
  }

  try {
    const { instructions, input } = req.body || {};
    if (!Array.isArray(input) || input.length === 0) {
      return res.status(400).json({ error: "Please enter a question and try again." });
    }

    const upstream = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${apiKey}`
      },
      body: JSON.stringify({
        model: "gpt-4.1-mini",
        instructions: typeof instructions === "string" ? instructions.slice(0, 6000) : "You are a helpful finance tutor. Give educational information, not personal financial advice.",
        input: input.slice(-8)
      })
    });

    const data = await upstream.json();
    if (!upstream.ok) {
      const message = data?.error?.message || "OpenAI could not process this request.";
      return res.status(upstream.status).json({ error: message });
    }

    return res.status(200).json({ answer: data.output_text || "I couldn't find a text answer. Please try asking another way." });
  } catch (error) {
    return res.status(500).json({ error: "Something went wrong while contacting the AI service." });
  }
}
