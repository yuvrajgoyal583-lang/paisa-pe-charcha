PAISA PE CHARCHA - BEGINNER SETUP

This folder contains your existing website connected to a secure OpenAI API route.

FILES
- index.html       Your website
- api/chat.js      Secure server-side connection to OpenAI
- package.json     Project settings

IMPORTANT
Do not put your OpenAI API key in index.html or share it with anyone.

PUBLISH USING GITHUB + VERCEL
1. Create/sign in to a GitHub account: https://github.com
2. Create a new repository. Name it paisa-pe-charcha. Choose Public or Private, then Create repository.
3. On the new repository page choose Add file > Upload files.
4. Open this ZIP on your computer. Upload the CONTENTS of the paisa-pe-charcha folder (index.html, package.json, README.txt and the api folder). Do not upload the ZIP itself.
5. Click Commit changes.
6. Create/sign in to Vercel: https://vercel.com
7. Click Add New > Project, connect GitHub if asked, and Import the paisa-pe-charcha repository.
8. Keep the default settings and click Deploy.
9. In Vercel open your project > Settings > Environment Variables.
10. Add a variable named OPENAI_API_KEY. Paste your secret API key as its value. Choose Production (and Preview if you want), then Save.
11. Open Deployments and redeploy the latest deployment (or use Deployments > ... > Redeploy).
12. Open the website URL Vercel gives you and test a simple question.

GET AN OPENAI API KEY
https://platform.openai.com/api-keys
Create a secret key and copy it once. Keep it private. API billing is separate from a ChatGPT subscription.

If the site shows an error, do not share your API key. Share only the error message or a screenshot with the key hidden.
